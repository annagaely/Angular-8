import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactsComponent } from './contacts/contacts.component';
import { NotFoundComponent } from './contacts/not-found/not-found.component';
import { ViewUserComponent } from './contacts/view-user/view-user.component';
const routes: Routes = [
  { path: '', redirectTo: '/contact-list', pathMatch: 'full' },
  { path: 'contact-list', component: ContactsComponent },
  // { path: 'view/:id', component: ViewUserComponent},
  { path: 'contact-list/:id', component: ViewUserComponent},
  { path: '404', component: NotFoundComponent },
  { path: '**', redirectTo: '/404'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
