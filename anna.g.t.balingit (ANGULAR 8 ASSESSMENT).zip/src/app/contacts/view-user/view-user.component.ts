import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DataStorageService } from 'src/app/shared/data-storage.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
  index: number;
  usersList = [];
  user = {};

  constructor(private route: ActivatedRoute,
              private dssService: DataStorageService) { }
  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      this.index = parseInt(params['id']);
      this.user = this.dssService.getUser(this.index);
    })
  }
  // this.route.params.subscribe((params: Params) => {
  //   this.index = parseInt(params['id']);
  //   this.user = this.dssService.getUser(this.index);
 
  // const id =+ this.route.snapshot.params['id'];
  // this.user = this.dssService.getUser(id);
  // this.route.params.subscribe(
  //   (params: Params) => {
  //   this.user = this.dssService.getUser(+params['id']);
  //   }
  // )
}
