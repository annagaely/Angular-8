import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';
import { User } from 'src/app/shared/user.model';
import { DataStorageService } from 'src/app/shared/data-storage.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit, OnChanges{
  contactForm: FormGroup;
  updateMode: boolean = false;
  // emailRegEx = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';
  @Input() updateContactIndex: number = 0;
  constructor(private dsService: DataStorageService) {}
  
  ngOnInit() {
    this.usersForm();
  }
  id: number = 0;

  //add
  onAddUser() {
    if (this.updateMode === false) {
      let index: number = 0;
      let usersList = this.dsService.getUserList();
      index = parseInt(usersList[usersList.length - 1].id) + 1;

      const newUser = new User(
        index,
        this.contactForm.value['name'],
        this.contactForm.value['email'],
      this.contactForm.value['phone']
      )
      this.dsService.addUser(newUser).subscribe((
        responseDate: Response) => {
          //
        })
        this.dsService.addUserList(newUser);
        this.contactForm.reset();
    }
    //update
    else {
      const id = parseInt(this.dsService.getUser(this.updateContactIndex).id);
      const newUser = new User(
        id,
        this.contactForm.value['name'],
        this.contactForm.value['email'],
        this.contactForm.value['phone']
      )
      this.dsService.updateUser(id, newUser).subscribe((
        responseDate: Response) => {
          console.log(responseDate);
        })
      this.dsService.updateUserList(this.updateContactIndex, newUser);
      this.contactForm.reset();
      this.updateMode = false;
    }
  }
  //form validations
  usersForm() {
    
    this.contactForm = new FormGroup({
      'name': new FormControl(null, Validators.required),
      'email': new FormControl(null, [Validators.required, Validators.email]),
      'phone': new FormControl(null, Validators.required)
    })
  }
  ngOnChanges() {
    if (this.contactForm != null) {
      const user = this.dsService.getUser(this.updateContactIndex);
      this.contactForm.setValue({
        name: user.name,
        email: user.email,
        phone: user.phone
      })
      this.updateMode = true;
    }
  }
}
