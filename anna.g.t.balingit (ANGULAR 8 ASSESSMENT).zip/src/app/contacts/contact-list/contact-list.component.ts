import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DataStorageService } from 'src/app/shared/data-storage.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  private Users: any;
  @Output() updateContactIndex = new EventEmitter();
  


  constructor(private dsService: DataStorageService,
              private router: Router,
              private route: ActivatedRoute) { }
  ngOnInit() {
    this.dsService.fetchData().subscribe((
      responseData: Response) => {
        this.dsService.saveUser(responseData);
        this.Users = responseData;
        // console.log(responseData);
      });
  }

  onDeleteUser(index: number) {
    this.dsService.deleteUser(index);
  }

  onViewUser(index: number) {
    this.router.navigate([index], {relativeTo: this.route})
  }

  onUpdateUser(index: number) {
    this.updateContactIndex.emit(index);
  }

}
