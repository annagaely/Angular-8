import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { User } from './user.model';
import { Subject } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class DataStorageService {
  apiUrl = "https://jsonplaceholder.typicode.com/users/";
  gotUsers: any;

  constructor(private http: HttpClient) { }
  //pang get from rest api
  fetchData() {
    return this.http.get(this.apiUrl);
  }
  //pag store sa User
  saveUser(Users) {
    this.gotUsers = Users;
  }

  // deleteUser(index: number) {
  //   this.gotUsers.splice(index, 1);
  //   this.http.delete(this.apiUrl+index)
  //   .subscribe((responseData: Response) => {
  //       console.log(responseData);
  //     })
  // }
  deleteUser(index: number) {
    this.http.delete(this.apiUrl+this.gotUsers[index].id)
    .subscribe((responseData: Response) => {
      console.log(responseData);
    });
    this.gotUsers.splice(index, 1);
    // this.updateUserList.next(this.gotUsers.slice());
  }
  getUserList(){
    return this.gotUsers;
  }
  addUser(newUser){
    return this.http.post(this.apiUrl, newUser);
  }

  addUserList(newUser: any){
    this.gotUsers.push(newUser);
  } 
  getUser(index: number) {
    return this.gotUsers[index];
  }

  updateUser(id, newUser) {
    return this.http.put(this.apiUrl+id, newUser);
  }
  updateUserList(index, newUser) {
    this.gotUsers[index] = newUser;
  }
}
